import './App.css';
import Template from './components/Template';
import store from './components/store';
import Provider from "react-redux";


const App = () => {
  return (
    <>
      <Provider store={store}>
        <Template />
      </Provider>
    </>
  );
}

export default App;
