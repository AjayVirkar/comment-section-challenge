
export default action = () => {
  type: true;
  Payload: Data;
}